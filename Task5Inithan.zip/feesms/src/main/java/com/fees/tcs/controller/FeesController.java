package com.fees.tcs.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fees.tcs.entity.Student;
import com.fees.tcs.repository.StudentFeesRepo;



@RestController
@RequestMapping("/fees")
public class FeesController {
	
	@Autowired
	private StudentFeesRepo studentFeesRepo;
	
	//An API to pay fees for a student
	@PostMapping("/studentFeesPay")
	public Student studentFeesPay(@RequestBody Student student) {
		int id = studentFeesRepo.getStudentId();
		student.setStudent_ID(id);
		student.getFeesList().stream().forEach(f -> f.setStudent_ID(id));
		
	return studentFeesRepo.save(student);	
	}
	
	 //An API to fetch all students 
	 @GetMapping("/fetchStudentFees/{id}") 
	 public Optional<Student> fetchStudentFees(@PathVariable Integer id){
	 return studentFeesRepo.findById(id); 
	 }
	 
	
}
