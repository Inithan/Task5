CREATE TABLE Student (
    Student_ID INT PRIMARY KEY,
    First_Name VARCHAR(50),
    Last_Name VARCHAR(50),
    DOB DATE,
    Gender VARCHAR(10),
    Address VARCHAR(255),
    Email VARCHAR(100),
    Major_Program VARCHAR(50),
    GPA DECIMAL(3, 2),
    Status VARCHAR(20)
);
commit;
INSERT INTO Student VALUES
(1, 'John', 'Doe', '1995-03-15', 'Male', '123 Main St, Cityville', 'john.doe@email.com', 'Computer Science', 3.5, 'Active'),
(2, 'Jane', 'Smith', '1998-07-22', 'Female', '456 Oak St, Townsville', 'jane.smith@email.com', 'Psychology', 3.2, 'Graduated'),
(3, 'Bob', 'Johnson', '1997-01-10', 'Male', '789 Pine St, Villagetown', 'bob.johnson@email.com', 'Business Administration', 3.8, 'Active'),
(4, 'Alice', 'Williams', '1996-05-03', 'Female', '101 Cedar St, Hamletville', 'alice.williams@email.com', 'Physics', 3.9, 'Graduated'),
(5, 'Charlie', 'Brown', '1999-11-28', 'Male', '202 Birch St, Riverside', 'charlie.brown@email.com', 'English Literature', 3.1, 'Active');
commit;