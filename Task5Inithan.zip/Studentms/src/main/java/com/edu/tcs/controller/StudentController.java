package com.edu.tcs.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edu.tcs.entity.Student;
import com.edu.tcs.repository.StudentRepo;

@RestController
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	private StudentRepo studentRepo;
	
	
	//An API to fetch all students
	@GetMapping("/fetchAllStudents")
	public List<Student> fetchAllStudents(){
		return studentRepo.findAll();
	}
	
	
	//An API to fetch a single student
	@GetMapping("/getStudent/{id}")
	public Optional<Student> getStudent(@PathVariable int id){
		return studentRepo.findById(id);	
	}
	
	
	//An API to create a new student
	@PostMapping("/createStudent")
	public Student createStudent(@RequestBody Student student){
		return studentRepo.save(student);	
	}
	
	
	//An API to delete a student
	@DeleteMapping("/deleteStudent/{id}")
	public String deleteStudent(@PathVariable int id){
		 studentRepo.deleteById(id);	
		 return "Deleted Student with ID" + id;
	}
	
	
	//An API to update a student
	@PostMapping("/updateStudent")
	public Student updateStudent(@RequestBody Student student){
		return studentRepo.save(student);	
	}

}
